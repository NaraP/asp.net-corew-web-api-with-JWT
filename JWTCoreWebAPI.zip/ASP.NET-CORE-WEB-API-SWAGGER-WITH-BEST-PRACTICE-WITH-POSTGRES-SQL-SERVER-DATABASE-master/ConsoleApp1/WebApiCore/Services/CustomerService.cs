﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using WebApiCore.Dto;
using WebApiCore.Helper;
using WebApiCore.IServices;
using WebApiCore.Mapper;
using WebApiCore.Repository.Customers;

namespace WebApiCore.Services
{
    /// <summary>
    /// CustomerService
    /// </summary>
    public class CustomerService : ICustomerService
    {

        private readonly ICustomerRepository _customerRepository;
        private readonly ILogger<CustomerService> _logger;

        /// <summary>
        /// CustomerService
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="customerRepository"></param>
        public CustomerService(ILogger<CustomerService> logger, ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
            _logger = logger;
        }

        /// <summary>
        /// AddCustomers
        /// </summary>
        /// <param name="customerDto"></param>
        /// <returns></returns>
        public async Task<ResponseMessage> AddCustomers(CustomerDto customerDto)
        {
            _logger.LogInformation($"Service-AddCustomers-Executing started at {DateTime.UtcNow}");

            var response = new ResponseMessage();

            response.returnObj = default(CustomerDto);

            try
            {
                if (customerDto != null)
                {
                    var customer = CustomerMapper.CustomerDtoToCustomer(customerDto);  // mapping role dto to role model

                    var result = await _customerRepository.AddCustomers(customer).ConfigureAwait(false);      //calling repository class method to add new role details to database

                    if (result > 0)
                    {
                        response.StatusCode = (int)HttpStatusCode.Created;

                        response.StatusDescription = HttpStatusCode.Created.ToString();
                        response.ErrorMessage = "Customer created successfully!";
                    }
                }

                _logger.LogInformation($"Service-AddCustomers-Executing completed at {DateTime.UtcNow}");
            }

            catch (Exception ex)
            {
            }
            return response;
        }
    }
}
