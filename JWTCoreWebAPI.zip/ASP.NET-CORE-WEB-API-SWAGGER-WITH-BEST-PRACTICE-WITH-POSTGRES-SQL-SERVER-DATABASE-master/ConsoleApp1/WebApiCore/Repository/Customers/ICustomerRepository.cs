﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCore.Helper;
using WebApiCore.Models;

namespace WebApiCore.Repository.Customers
{
    public interface ICustomerRepository
    {
        Task<int> AddCustomers(Customer customer);

       // Task<int> AddCustomer(string customer);
    }
}
