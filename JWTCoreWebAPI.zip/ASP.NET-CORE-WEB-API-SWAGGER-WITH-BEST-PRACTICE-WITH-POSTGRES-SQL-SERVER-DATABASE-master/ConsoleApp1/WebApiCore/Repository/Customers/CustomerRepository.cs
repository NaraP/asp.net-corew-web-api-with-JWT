﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCore.Models;

namespace WebApiCore.Repository.Customers
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly SampleDbContext _sampleDbContext;

        private readonly IHttpContextAccessor _httpContextAccessor;

        /// <summary>
        /// CustomerRepository
        /// </summary>
        /// <param name="sampleDbContext"></param>
        /// <param name="httpContextAccessor"></param>
        public CustomerRepository(SampleDbContext sampleDbContext, IHttpContextAccessor httpContextAccessor)
        {
            _sampleDbContext = sampleDbContext;
            _httpContextAccessor = httpContextAccessor;
        }


        public async Task<int> AddCustomers(Customer customer)
        {
            await _sampleDbContext.Customer.AddAsync(customer);

            return await _sampleDbContext.SaveChangesAsync().ConfigureAwait(false);
        }
    }
}
