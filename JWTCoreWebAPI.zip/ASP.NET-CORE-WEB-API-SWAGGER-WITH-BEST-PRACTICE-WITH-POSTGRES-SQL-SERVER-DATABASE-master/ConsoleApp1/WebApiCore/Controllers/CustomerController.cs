﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebApiCore.Dto;
using WebApiCore.IServices;

namespace WebApiCore.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("Customer/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomerService _customerService;
        private readonly IHostingEnvironment _env;

        private readonly ILogger<CustomerController> _customerLogger;

        /// <summary>
        /// CustomerController
        /// </summary>
        /// <param name="env"></param>
        /// <param name="customerService"></param>
        /// <param name="customerLogger"></param>
        public CustomerController(IHostingEnvironment env, ICustomerService customerService, ILogger<CustomerController> customerLogger)
        {
            _customerService = customerService;
            _customerLogger = customerLogger;
            _env = env;
        }

        /// <summary>
        /// AddCustomer
        /// </summary>
        /// <param name="customerDto"></param>
        /// <returns></returns>
        [HttpPost("AddCustomer", Name = nameof(AddCustomer))]
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [ProducesResponseType(409)]
        [ProducesResponseType(500)]
        public async Task<ActionResult> AddCustomer([FromBody] CustomerDto customerDto)
        {
            try
            {
                using (_customerLogger.BeginScope($"API-AddCustomer {DateTime.UtcNow}"))
                {
                    var result = await _customerService.AddCustomers(customerDto).ConfigureAwait(false);

                    _customerLogger.LogInformation($"API-AddCustomer {DateTime.UtcNow}");

                    return StatusCode(result.StatusCode, result);
                }
            }
            catch (Exception ex)
            {
                _customerLogger.LogError
                    (ex,
                     $"API-AddRole-Exception {DateTime.UtcNow}"
                   );

                return StatusCode((int)HttpStatusCode.InternalServerError, _env.IsDevelopment() ? ex.ToString() : "An error occured while processing AddCustomer");
            }
        }

    }
}