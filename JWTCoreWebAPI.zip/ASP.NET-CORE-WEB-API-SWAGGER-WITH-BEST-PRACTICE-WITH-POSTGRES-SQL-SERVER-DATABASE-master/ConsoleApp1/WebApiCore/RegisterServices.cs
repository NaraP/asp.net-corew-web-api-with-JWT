﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiCore.IServices;
using WebApiCore.Repository.Customers;
using WebApiCore.Services;

namespace WebApiCore
{
    /// <summary>
    /// RegisterServices
    /// </summary>
    public static class RegisterServices
    {
        /// <summary>
        /// RegisterConfigServices
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        public static void RegisterConfigServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<ICustomerService, CustomerService>();
            services.AddScoped<ICustomerRepository, CustomerRepository>();
        }
    }
}
