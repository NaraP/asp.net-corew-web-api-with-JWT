﻿using Elasticsearch.Net;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Nest;
using Serilog;
using Serilog.Events;
using Serilog.Exceptions;
using Serilog.Sinks.Elasticsearch;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace ConsoleApp1
{
	public class Metadata
	{
		public int Id { get; set; }

		public DateTime Timestamp { get; set; }

		//[String(Index = FieldIndexOption.NotAnalyzed)]
		public string Type { get; set; }
	}

	class disney
	{
		public string name { get; set; }
		public string original_voice_actor { get; set; }
		public string animated_debut { get; set; }
	}
	class Program
	{
		private static IElasticClient _client;

		public Program(IElasticClient client)
		{
			_client = client;
		}

		public void CreateIndex(string indexName)
		{
			//if (!_client.Index(indexName).Exists)
			//{
			//	_client.Create(indexName);
			//}
		}

		public static void Insert(Car car, string indexName, string indexType, ElasticClient client)
		{
			client.Index(car, i => i
				  .Id(car.CarID)
				  .Index(indexName)
				  //.OpType(indexType.ToString())
				  );
		}

		public static Car getCarByID(string Id, string indexName, string typeName, ElasticClient client)
		{
			var result = client.Search<Car>(q => q
							  .Index(indexName)
							 // .Type(typeName)
							  .Query(qq => qq.Match(m => m.Field(f => f.CarID).Query(Id))
							  ).Size(1));

			return result.Documents.FirstOrDefault();
		}

		static void Main(string[] args)
		{
			//configure logging first
			ElasticHelper.ConfigureLogging();

			//then create the host, so that if the host fails we can log errors
			ElasticHelper.CreateHost(args);
			Log.Debug("testing the console app elastic search");
			Log.Debug("testing the console app elastic search");
			Log.Information("testing the console app elastic search");

			Log.Information("Hello Elastic!");

			List<string> First = new List<string>();
			First.Add("A");
			First.Add("D");
			First.Add("B");
			First.Add("C");

			List<string> List = new List<string>();

			List.Add("C");
			List.Add("B");


			IEnumerable<string> Third;
			Third = First.Except(List);



			var pool = new SingleNodeConnectionPool(new Uri("http://52.172.25.120:32894"));
			var defaultIndex = "default";
			var connectionSettings = new ConnectionSettings(pool)
					.DefaultIndex(defaultIndex);

			Car car = new Car()
			{
				CarID = 55,
				Color = "Black",
				CreatedDate = DateTime.Now,
				Maker = "TOYOTA",
				Milage = 27.39,
				Price = 7170000
			};
			string indexName = "vehicles";
			string indexType = "car";


			var client = new ElasticClient(connectionSettings);

			Insert(car, indexName, indexType, client);

			Car car1 = getCarByID("55", indexName, indexType, client);

			//var result = client.Search(q => q
			//				  .Index(indexName)
			//				  .Type(typeName)
			//				  .Query(qq => qq.Match(m => m.Field(f => f.CarID).Query(Id))
			//				  ).Size(1));
			//var response = client.Search<disney>(s => s

			//var results = result.Documents.FirstOrDefault();



			//	var response = client.Search<disney>(s => s
			//.Index("defaultIndex")
			//.Query(q => q.QueryString(qs => qs.Query("*"))));





			//	var metadata = Enumerable.Range(1, 1000).Select(i =>
			//		new Metadata
			//		{
			//			Id = i,
			//			Timestamp = DateTime.UtcNow.Date.AddDays(-(i - 1)),
			//			Type = i % 2 == 0 ? "metadata-type-2" : "metadata-type-1"
			//		});

			//	client.IndexMany(metadata);
			//	//client.Refresh(defaultIndex);

			//	var Type = "metadata-type-1";
			//	var NumberOfItems = 5;

			//	var searchResponse = client.Search<Metadata>(s => s
			//		.Query(q => q
			//			.Term(f => f.Type, Type)
			//		)
			//		.Size(NumberOfItems)
			//		.Sort(sort => sort
			//			.Descending(f => f.Timestamp)
			//		)
			//	);
			//}


			//private static ElasticsearchSinkOptions ConfigureElasticSink(IConfigurationRoot configuration, string environment)
			//{
			//	return new ElasticsearchSinkOptions(new Uri(configuration["ElasticConfiguration:Uri"]))
			//	{
			//		AutoRegisterTemplate = true,
			//		IndexFormat = $"{Assembly.GetExecutingAssembly().GetName().Name.ToLower().Replace(".", "-")}-{environment?.ToLower().Replace(".", "-")}-{DateTime.UtcNow:yyyy-MM}"
			//	};
			//}

			//private static void CreateHost(string[] args)
			//{
			//	try
			//	{
			//		//CreateHostBuilder(args).Build().Run();
			//	}
			//	catch (System.Exception ex)
			//	{
			//		Log.Fatal($"Failed to start {Assembly.GetExecutingAssembly().GetName().Name}", ex);
			//		throw;
			//	}
			//}

		}

		private static void CreateHost(string[] args)
		{
			try
			{
				var host = new HostBuilder().Build();
				host.Run();
			}

			catch (System.Exception ex)
			{
				Log.Fatal($"Failed to start {Assembly.GetExecutingAssembly().GetName().Name}", ex);
				throw;
			}
		}

		private static void ConfigureLogging()
		{
			var environment = Environment.GetEnvironmentVariable("ElasticConfigurationUrl");

			var configuration = new ConfigurationBuilder()
				.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
				.AddJsonFile(
					$"appsettings.{Environment.GetEnvironmentVariable("ElasticConfigurationUrl")}.json",
					optional: true).AddEnvironmentVariables()
				.Build();

			if (!String.IsNullOrEmpty(environment))
			{
				Log.Logger = new LoggerConfiguration()
				   .Enrich.FromLogContext()
				   .Enrich.WithExceptionDetails()
				   .Enrich.WithMachineName()
				   .WriteTo.Elasticsearch(new ElasticsearchSinkOptions(new Uri(environment))
				   {
					   AutoRegisterTemplate = true,
					   MinimumLogEventLevel = LogEventLevel.Verbose
				   })
				.CreateLogger();
			}
		}

		private static ElasticsearchSinkOptions ConfigureElasticSink(IConfigurationRoot configuration, string environment)
		{
			return new ElasticsearchSinkOptions(new Uri(environment))
			{
				AutoRegisterTemplate = true,
				IndexFormat = $"{Assembly.GetExecutingAssembly().GetName().Name.ToLower().Replace(".", "-")}-{environment?.ToLower().Replace(".", "-")}-{DateTime.UtcNow:yyyy-MM}"
			};
		}
	}
}
