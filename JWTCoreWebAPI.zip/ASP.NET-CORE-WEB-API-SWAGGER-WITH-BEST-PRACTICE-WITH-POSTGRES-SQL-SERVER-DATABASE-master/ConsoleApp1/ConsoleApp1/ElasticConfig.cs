﻿using Elasticsearch.Net;
using Nest;
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public static class ElasticConfig
    {
        private static IElasticClient _client;
        static ElasticConfig()
        {
            var node1 = new Uri("http://localhost:9200/");
            var node2 = new Uri("http://152.30.11.192:9200/");
            var nodes = new Uri[]
            {
                node1
               //,node2
            };
            var connectionPool = new SniffingConnectionPool(nodes);
            var connectionSettings = new ConnectionSettings(connectionPool)
                                .SniffOnConnectionFault(false)
                                .SniffOnStartup(false)
                                .SniffLifeSpan(TimeSpan.FromMinutes(1));
            _client = new ElasticClient(connectionSettings);
        }
        public static IElasticClient GetClient()
        {
            return _client;
        }
    }
}
